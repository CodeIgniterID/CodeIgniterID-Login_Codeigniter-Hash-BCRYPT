<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Page404 extends CI_Controller {

	public function index()
	{
		 $this->template->load('role','p404'); 
	}

}

/* End of file Page404.php */
/* Location: ./application/controllers/Page404.php */