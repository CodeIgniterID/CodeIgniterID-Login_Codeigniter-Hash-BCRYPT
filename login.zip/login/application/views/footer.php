    <!-- Footer -->
    <footer class="py-2 bg-dark">
      <div class="container">
        <p class="m-0 text-center text-white"><small>&copy; Copyright 2018, Codeigniter ID  - Login secure with session & hash BCRYPT.</small></p>
      </div>
      <!-- /.container -->
    </footer>
    <!-- Bootstrap core JavaScript -->
    <script src="<?php echo base_url('assets');?>/vendor/jquery/jquery.min.js"></script>
    <script src="<?php echo base_url('assets');?>/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <!-- Plugin JavaScript -->
    <script src="<?php echo base_url('assets');?>/vendor/jquery-easing/jquery.easing.min.js"></script>
    <!-- Custom JavaScript for this theme -->
    <script src="<?php echo base_url('assets');?>/js/scrolling-nav.js"></script>
  </body>

</html>
